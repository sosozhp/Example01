package zhp;

import java.util.List;

public class WikiGenerator {

	static final String cf = "\n";
	static final String sp = " | ";
	static final String space = " ";
	
	private List<MethodInfo> listMethod = null;
	private String classMappingPath;
	private String hostPath;
	
	public void setClassMappingPath(String classMappingPath){
		this.classMappingPath = classMappingPath;
	}
	public void setHostPath(String hostPath){
		this.hostPath = hostPath;
	}
	public void setMethods(List<MethodInfo> listMethod){
		this.listMethod = listMethod;
	}
	
	
	public String makeWikiDoc(){
		String doc = "";
		//api list
		doc += this.makeAPIlist();
		//methods
		doc += this.makeMethods();
		return doc;
	}
	
	private String makeMethods(){
		String ms = "";
		for(MethodInfo mi : this.listMethod){
			ms = ms + this.makeOneMethod(mi);
			ms = ms + cf;
		}
		return ms;
	}
	private String makeOneMethod(MethodInfo mi){
		StringBuffer sb = new StringBuffer();
    	//description
		sb.append(this.makeMethodDescription(mi));    	
    	//request
		sb.append(this.makeMethodRequest(mi)); 
    	//response
		sb.append(this.makeMethodResponse(mi)); 
    	//crud
		sb.append(this.makeMethodCRUD(mi));
		return sb.toString();
	}
	
	private String makeMethodDescription(MethodInfo mi){
		StringBuffer sb = new StringBuffer();
		sb.append("#### ").append( wrapNumber(mi.getNo())).append(space).append(space).append(classMappingPath).append(mi.getResource());
    	sb.append(cf).append(cf);
    	sb.append("- Description");
    	sb.append(cf).append(cf);
    	sb.append( wrapString("TODO Something for description.") );
    	sb.append(cf).append(cf);
		return sb.toString();
	}
	private String makeMethodRequest(MethodInfo mi){
		StringBuffer sb = new StringBuffer();
		sb.append("- Request");
    	sb.append(cf).append(cf);
    	sb.append("Parameter Name | type     | value(eg)  | Not Null | Description");
    	sb.append(cf);
    	sb.append(":------------- | :------- | :--------- | :------- | :-------------------");
    	sb.append(cf);
    	if( mi.getReqInfo().getParams().size() > 0 ){
        	for( ParameterInfo p : mi.getReqInfo().getParams() ){
        		sb.append(p.getName()).append(sp)
        		  .append(p.getType()).append(sp)
        		  .append(sp)
        		  .append(sp)
        		  .append(cf);
        	}
    	}else{
    		sb.append("なし").append(sp).append(sp).append(sp).append(sp).append(cf);
    	}
    	sb.append(cf);
    	sb.append("You can test the sample API using the following URL:").append(cf).append(cf);
    	sb.append( wrapString( hostPath + classMappingPath + mi.getResource()) ).append(cf).append(cf);
		return sb.toString();
	}
	private String makeMethodResponse(MethodInfo mi){
		StringBuffer sb = new StringBuffer();
		sb.append("- Response");
    	sb.append(cf).append(cf);
    	sb.append("正常状態:").append(mi.getResInfo().getCodeOK()).append(cf).append(cf);
       	sb.append("正常結果:").append(cf).append(cf);
       	sb.append(wrapJson(mi.getResInfo().getResultOK())).append(cf).append(cf);
       	sb.append("異常状態:").append(mi.getResInfo().getCodeNG()).append(cf).append(cf);
    	sb.append("異常結果:").append("").append(cf).append(cf);
    	sb.append(wrapJson(mi.getResInfo().getResultNG())).append(cf).append(cf);
		return sb.toString();
	}
	private String makeMethodCRUD(MethodInfo mi){
		StringBuffer sb = new StringBuffer();
		sb.append("- CRUD").append(cf).append(cf);
		sb.append("No   | operation | table name                | discription").append(cf);
    	sb.append(":--- | :---------- | :---------------------- | :----------------------------------------").append(cf);
    	if( mi.getCurdInfo().size() > 0 ){
        	for( CRUDInfo c : mi.getCurdInfo() ){
        		sb.append(c.getNo()).append(sp)
        		  .append(c.getOperation()).append(sp)
        		  .append(c.getTablename()).append(sp)
        		  .append(c.getDiscription()).append(sp)
        		  .append(cf);
        	}
    	}else{
    		sb.append("なし").append(sp).append(sp).append(sp).append(sp).append(cf);
    	}
		return sb.toString();
	}
	
	private String makeAPIlist(){
		StringBuffer sb = new StringBuffer();
		
		sb.append("#### API一覧").append(cf);
    	sb.append("No   | http method | resource                                                    | State").append(cf);
    	sb.append(":--- | :---------- | :---------------------------------------------------------- | :----").append(cf);
    	for( MethodInfo mi : listMethod ){
    		sb.append( wrapNumber(mi.getNo())).append(sp);
    		sb.append(mi.getType()).append(sp);
    		sb.append(classMappingPath + mi.resource).append(sp);
    		sb.append("完了").append(cf);
    	}
		return sb.toString();
	}
	
	private String wrapNumber(String input){
		input = input.replaceAll("0", ":zero:");
		input = input.replaceAll("1", ":one:");
		input = input.replaceAll("2", ":two:");
		input = input.replaceAll("3", ":three:");
		input = input.replaceAll("4", ":four:");
		input = input.replaceAll("5", ":five:");
		input = input.replaceAll("6", ":six:");
		input = input.replaceAll("7", ":seven:");
		input = input.replaceAll("8", ":eight:");
		input = input.replaceAll("9", ":nine:");
		return input;
	}
	
	private String wrapString(String input){
		return "`" + input + "`";
	}
	private String wrapJson(String input){
		return "```json" + cf + input + cf + " ```"; 
	}
	
}
