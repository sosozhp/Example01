package zhp;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;

public class MethodInfoMgr {

    private Class targetclass;
    private static String hostPath = "http://localhost:8080";
    private static String classMappingPath;
    private static List<MethodInfo> listMethod = new ArrayList<MethodInfo>();
    private static String[] methodNameExclude = {"lamb","convert"};
    private static String CF = "\n";
    
    
    private static MethodInfoMgr instance = new MethodInfoMgr();
    private MethodInfoMgr(){
        System.out.println("インスタンスを作成しました。");
    }
    public static MethodInfoMgr getInstance(){
        return instance;
    }

    public static List<MethodInfo> getlistMethod(){
        return listMethod;
    }

    //setup
    public void setup(Class targetClass){
        this.instance.targetclass = targetClass;
        
        classMappingPath = getClassMappingPath();
        int indexNo = 0;
        
        Method[] ms = this.instance.targetclass.getDeclaredMethods();
        for(Method m : ms){

        	//対象外メソッドは不要
        	if(isExcludeMethod(m.getName())){
        		continue;
        	}
        	//create method info
            MethodInfo mi = new MethodInfo();
            //No
        	indexNo++;
        	mi.setNo(String.valueOf(indexNo));
            
            //create method description
            mi.setDescription(m.getName());

            //set method info
            addCommonInfo(m,mi);
            addRequestInfo(m,mi);
            addResponseInfo(m,mi);
            addCRUDInfo(m,mi);
            listMethod.add(mi);
        }
    }

    private void addCommonInfo(Method m, MethodInfo mi){
    	
    	String httpType = "";
    	String resource = "";
		 if (m.getAnnotation(GetMapping.class) != null){
			 GetMapping e = m.getAnnotation(GetMapping.class);
			 httpType = "GET";
			 if(e.value() != null && e.value().length > 0 ){
				 resource = e.value()[0];
			 }
			 //System.out.println("annotation value:" + e.value()[0] + ":" );
		 }else if(m.getAnnotation(PutMapping.class) != null){
			 PutMapping e = m.getAnnotation(PutMapping.class);
			 httpType = "PUT";
			 if(e.value() != null && e.value().length > 0 ){
				 resource = e.value()[0];
			 }
		 }else if(m.getAnnotation(PostMapping.class) != null){
			 PostMapping e = m.getAnnotation(PostMapping.class);
			 httpType = "POST";
			 if(e.value() != null && e.value().length > 0 ){
				 resource = e.value()[0];
			 }
		 }else if(m.getAnnotation(DeleteMapping.class) != null){
			 DeleteMapping e = m.getAnnotation(DeleteMapping.class);
			 httpType = "DELETE";
			 if(e.value() != null && e.value().length > 0 ){
				 resource = e.value()[0];
			 }
		 }
		 
		 mi.setType(httpType);
		 mi.setResource(resource);
    }
    
    private void addRequestInfo(Method m, MethodInfo mi){
    	
    	RequestInfo reqInfo = new RequestInfo();
    	
    	//parameter set
    	ArrayList<ParameterInfo> listParameter = new ArrayList<ParameterInfo>();
    	Parameter[] ps =  m.getParameters();
        for(Parameter p : ps){
        	ParameterInfo pi = new ParameterInfo();
        	pi.setType(p.getType().getSimpleName() );
        	pi.setName(p.getName());
        	listParameter.add(pi);
        }
        reqInfo.setParams(listParameter);
        
        //sample url
        reqInfo.setSampleUrl("http://localhost:8080/api/v1/XXX");
        
        //        
        mi.setReqInfo(reqInfo);
    }
   private void addResponseInfo(Method m, MethodInfo mi){
	   ResponseInfo resInfo = new ResponseInfo();
	   Annotation[] anns = m.getAnnotations();
		for (Annotation ann : anns) {
			if (ann instanceof ResponseStatus) {
				ResponseStatus statusAnn = (ResponseStatus) ann;
				if (statusAnn.value() != null) {
					resInfo.setCodeOK( String.valueOf(statusAnn.value()));
					break;
				}
			}
		}
		
	   resInfo.setResultOK("{TODO}");
	   resInfo.setCodeNG("404");
	   resInfo.setResultNG("{TODO}");
	   mi.setResInfo(resInfo);
    	
    }
   private void addCRUDInfo(Method m, MethodInfo mi){
   	
	   ArrayList<CRUDInfo> listCRUDInfo = new ArrayList<CRUDInfo>();
	   
	   CRUDInfo crud = new CRUDInfo();
	   crud.setNo("01");
	   crud.setOperation("SELECT");
	   crud.setTablename("XXX_Table");
	   crud.setDiscription("XXX_Comment");
	   
	   listCRUDInfo.add(crud);
	   mi.setCurdInfo(listCRUDInfo);
   }
    //
    private boolean isExcludeMethod(String methodName){
    	boolean result = false;
    	for(String testString : methodNameExclude ){
    		if (methodName.indexOf(testString) > -1){
    			return true;
    		}
    	}
    	return result;
    }

	private String getClassMappingPath() {
		String result = "";
		Annotation[] anns = this.targetclass.getAnnotations();
		for (Annotation ann : anns) {
			if (ann instanceof RequestMapping) {
				RequestMapping classAnn = (RequestMapping) ann;
				if (classAnn.value() != null && classAnn.value().length > 0) {
					result = classAnn.value()[0];
					return result;
				}
			}
		}
		return result;
	}

    //output------
    public static void output(){

    	WikiGenerator wg = new WikiGenerator();
    	wg.setMethods(listMethod);
    	wg.setClassMappingPath(classMappingPath);
    	wg.setHostPath(hostPath);
    	
    	String s = wg.makeWikiDoc();
    	System.out.println(s);

    };


}
