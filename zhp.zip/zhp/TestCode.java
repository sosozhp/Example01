package zhp;

import jp.co.aucnet.nmc.api.v1.BidRestControllerV1;

public class TestCode {

    public static void main(String[] args) {

        getApi();

        MethodInfoMgr.getInstance().setup(BidRestControllerV1.class);
        MethodInfoMgr.output();
    }


    public static void getApi(){

       //Method[] ms  =   MemberBazarSumControllerV1.class.getDeclaredMethods();

       //for(Method m : ms){

//           System.out.println("method:" +  m.getName());
//
//           if (m.getAnnotation(GetMapping.class) != null){
//               GetMapping e = m.getAnnotation(GetMapping.class);
//               System.out.println("annotation value:" + e.value()[0] + ":" );
//           }
//
//           Parameter[] ps = m.getParameters();
//
//           for(Parameter p : ps){
//
//               System.out.println("parameter:" + p.getName());
//           }

       //}

    }




}
