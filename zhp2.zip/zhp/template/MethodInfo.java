package zhp.template;

import java.util.ArrayList;
import java.util.List;

public class MethodInfo {

    public String no;
    public String functionName;
    public String description;
    public String status;
    public String type;
    public String resource;
    public RequestInfo reqInfo = new RequestInfo();
    public ResponseInfo resInfo = new ResponseInfo();
    public List<CRUDInfo> curdInfo = new ArrayList<CRUDInfo>();
    
    
	public String getNo() {
		return no;
	}
	public void setNo(String no) {
		this.no = no;
	}
	public String getFunctionName() {
		return functionName;
	}
	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getResource() {
		return resource;
	}
	public void setResource(String resource) {
		this.resource = resource;
	}
	public RequestInfo getReqInfo() {
		return reqInfo;
	}
	public void setReqInfo(RequestInfo reqInfo) {
		this.reqInfo = reqInfo;
	}
	public ResponseInfo getResInfo() {
		return resInfo;
	}
	public void setResInfo(ResponseInfo resInfo) {
		this.resInfo = resInfo;
	}
	public List<CRUDInfo> getCurdInfo() {
		return curdInfo;
	}
	public void setCurdInfo(List<CRUDInfo> curdInfo) {
		this.curdInfo = curdInfo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}


}
