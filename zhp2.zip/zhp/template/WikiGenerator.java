package zhp.template;

import java.util.List;

import zhp.render.RenderBase;
import zhp.util.Util;

public class WikiGenerator {

	static final String cf = "\n";
	static final String sp = " | ";
	static final String space = " ";

	private WikiDocument wikiDoc;
	private String hostPath;
	private String classMappingPath;
	private String wikiSummaryContent;
	private String wikiFormsContent;
	private List<MethodInfo> listMethod = null;
	
	public WikiGenerator(WikiDocument wikiDoc){
		this.wikiDoc = wikiDoc;
		this.hostPath = wikiDoc.getHostPath();
		this.classMappingPath = wikiDoc.getClassMappingPath();
		this.wikiSummaryContent = wikiDoc.getWikiSummaryContent();
		this.wikiFormsContent = wikiDoc.getWikiFormsContent();
		this.listMethod = wikiDoc.getListMethod();
	}
	
	public String makeWikiDoc(){
		String doc = "";

		//wiki summary
		doc += this.makeWikiSummaryContent();
		//wiki for forms
		doc += this.makeWikiFormsContent();
		//api list
		doc += this.makeAPIlist();
		//methods
		doc += this.makeMethods();
		return doc;
	}
	
	private String makeMethods(){
		String ms = "";
		for(MethodInfo mi : this.listMethod){
			ms = ms + this.makeOneMethod(mi);
			ms = ms + cf;
		}
		return ms;
	}
	private String makeOneMethod(MethodInfo mi){
		StringBuffer sb = new StringBuffer();
		//title
		sb.append(this.makeMethodTitle(mi));    	
    	//description
		sb.append(this.makeMethodDescription(mi));    	
    	//request
		sb.append(this.makeMethodRequest(mi)); 
    	//response
		sb.append(this.makeMethodResponse(mi)); 
    	//crud
		sb.append(this.makeMethodCRUD(mi));
		return sb.toString();
	}
	
	private String makeWikiSummaryContent(){
		StringBuffer sb = new StringBuffer();
		sb.append("#### 業務内容").append(cf);
		sb.append(space).append( Util.wrapString(wikiSummaryContent));
    	sb.append(cf).append(cf);
		return sb.toString();
	}
	private String makeWikiFormsContent(){
		StringBuffer sb = new StringBuffer();
		sb.append("#### 対応画面").append(cf);
		sb.append(space).append(wikiFormsContent);
    	sb.append(cf).append(cf);
		return sb.toString();
	}
	private String makeMethodTitle(MethodInfo mi){
		StringBuffer sb = new StringBuffer();
		sb.append("#### ").append( Util.wrapNumber(mi.getNo()))
			.append(space).append(space)
			.append(classMappingPath)
			.append(mi.getResource());
    	sb.append(cf).append(cf);
		return sb.toString();
	}
	private String makeMethodDescription(MethodInfo mi){
		StringBuffer sb = new StringBuffer();
		sb.append(Util.printDescriptionHeader());
    	sb.append(mi.getDescription() );
    	sb.append(cf).append(cf);
		return sb.toString();
	}
	private String makeMethodRequest(MethodInfo mi){
		StringBuffer sb = new StringBuffer();
		sb.append(Util.printRequestHeader());
    	if( mi.getReqInfo().getParams().size() > 0 ){
        	for( ParameterInfo p : mi.getReqInfo().getParams() ){
        		sb.append(p.getName()).append(sp)
        		  .append(p.getType()).append(sp)
        		  .append(p.getValueeg()).append(sp)
        		  .append(p.getNotNull()).append(sp)
        		  .append(p.getDescription()).append(cf);
        	}
    	}else{
    		sb.append("なし").append(sp).append(sp).append(sp).append(sp).append(cf);
    	}
    	sb.append(cf);
    	sb.append("You can test the sample API using the following URL:").append(cf).append(cf);
    	sb.append( Util.wrapString( hostPath + classMappingPath + mi.getResource()) ).append(cf).append(cf);
    	sb.append("ex:)").append(cf).append(cf);
    	sb.append( Util.wrapString( mi.getReqInfo().getSampleUrl())).append(cf).append(cf);
		return sb.toString();
	}
	private String makeMethodResponse(MethodInfo mi){
		StringBuffer sb = new StringBuffer();
		sb.append(Util.printResponseHeader());
    	sb.append("正常状態:").append(mi.getResInfo().getCodeOK()).append(cf).append(cf);
       	sb.append("正常結果:").append(cf).append(cf);
       	sb.append(Util.wrapJson(mi.getResInfo().getResultOK())).append(cf).append(cf);
       	sb.append("異常状態:").append(mi.getResInfo().getCodeNG()).append(cf).append(cf);
    	sb.append("異常結果:").append(cf).append(cf);
    	sb.append(Util.wrapJson(mi.getResInfo().getResultNG())).append(cf).append(cf);
		return sb.toString();
	}
	private String makeMethodCRUD(MethodInfo mi){
		StringBuffer sb = new StringBuffer();
		sb.append(Util.printCRUDHeader());
    	if( mi.getCurdInfo().size() > 0 ){
        	for( CRUDInfo c : mi.getCurdInfo() ){
        		sb.append(c.getNo()).append(sp)
        		  .append(c.getOperation()).append(sp)
        		  .append(c.getTablename()).append(sp)
        		  .append(c.getDiscription()).append(sp)
        		  .append(cf);
        	}
    	}else{
    		sb.append("なし").append(sp).append(sp).append(sp).append(sp).append(cf);
    	}
		return sb.toString();
	}
	
	private String makeAPIlist(){
		StringBuffer sb = new StringBuffer();
		sb.append(Util.printApiListHeader());
		for( MethodInfo mi : listMethod ){
    		sb.append( Util.wrapNumber(mi.getNo())).append(sp);
    		sb.append(mi.getType()).append(sp);
    		sb.append(classMappingPath + mi.resource).append(sp);
    		sb.append(mi.getStatus()).append(cf);
    	}
		return sb.toString();
	}
	
	public WikiDocument getWikiDoc() {
		return wikiDoc;
	}
	public void setWikiDoc(WikiDocument wikiDoc) {
		this.wikiDoc = wikiDoc;
	}
	
}
