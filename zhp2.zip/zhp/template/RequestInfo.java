package zhp.template;

import java.util.ArrayList;
import java.util.List;


public class RequestInfo {

    public List<ParameterInfo> params = new ArrayList<ParameterInfo>();

    public String sampleUrl;

    public List<ParameterInfo> getParams() {
        return params;
    }

    public void setParams(List<ParameterInfo> params) {
        this.params = params;
    }

    public String getSampleUrl() {
        return sampleUrl;
    }

    public void setSampleUrl(String sampleUrl) {
        this.sampleUrl = sampleUrl;
    }


}
