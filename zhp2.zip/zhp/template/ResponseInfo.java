package zhp.template;

public class ResponseInfo {

    public String codeOK;
    public String codeNG;

    public String resultOK;
    public String resultNG;


    public String getCodeOK() {
        return codeOK;
    }
    public void setCodeOK(String codeOK) {
        this.codeOK = codeOK;
    }
    public String getCodeNG() {
        return codeNG;
    }
    public void setCodeNG(String codeNG) {
        this.codeNG = codeNG;
    }
    public String getResultOK() {
        return resultOK;
    }
    public void setResultOK(String resultOK) {
        this.resultOK = resultOK;
    }
    public String getResultNG() {
        return resultNG;
    }
    public void setResultNG(String resultNG) {
        this.resultNG = resultNG;
    }




}
