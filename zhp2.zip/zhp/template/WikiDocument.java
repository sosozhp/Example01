package zhp.template;

import java.util.List;

import zhp.render.RenderBase;

public class WikiDocument {

	private String hostPath;
	private String classMappingPath;
	private String wikiSummaryContent;
	private String wikiFormsContent;
	private List<MethodInfo> listMethod = null;
	
	
	public String getHostPath() {
		return hostPath;
	}
	public void setHostPath(String hostPath) {
		this.hostPath = hostPath;
	}
	public String getClassMappingPath() {
		return classMappingPath;
	}
	public void setClassMappingPath(String classMappingPath) {
		this.classMappingPath = classMappingPath;
	}
	public String getWikiSummaryContent() {
		return wikiSummaryContent;
	}
	public void setWikiSummaryContent(String wikiSummaryContent) {
		this.wikiSummaryContent = wikiSummaryContent;
	}
	public String getWikiFormsContent() {
		return wikiFormsContent;
	}
	public void setWikiFormsContent(String wikiFormsContent) {
		this.wikiFormsContent = wikiFormsContent;
	}
	public List<MethodInfo> getListMethod() {
		return listMethod;
	}
	public void setListMethod(List<MethodInfo> listMethod) {
		this.listMethod = listMethod;
	}
	
}
