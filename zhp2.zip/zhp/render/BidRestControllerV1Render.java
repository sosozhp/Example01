package zhp.render;


import java.util.ArrayList;
import java.util.List;

import zhp.template.CRUDInfo;
import zhp.template.MethodInfo;
import zhp.template.ParameterInfo;
import zhp.template.WikiDocument;

public class BidRestControllerV1Render extends RenderBase {

	public BidRestControllerV1Render(){
		this.sdoc = new WikiDocument();
	}

	@Override
	void setWikiDocInfo() {
		// TODO Auto-generated method stub
		
		this.sdoc.setWikiSummaryContent("XXXの業務内容の説明文です。");
		this.sdoc.setWikiFormsContent("YYYの表示画面");
		
		ArrayList<MethodInfo> listMethodInfo = new ArrayList<MethodInfo>();
		listMethodInfo.add(this.delete());
		this.sdoc.setListMethod(listMethodInfo);
		//
	}
	
	//delete method.
	private MethodInfo delete(){
		
		MethodInfo mi = new MethodInfo();
		mi.setFunctionName("delete");;
		
		mi.setStatus("作成中");
		mi.setDescription("ここは、そのAPIの機能を書きます。");
		mi.getReqInfo().setSampleUrl("this is a sample url for method : delete .");
		
		//parameters
		List<ParameterInfo> listParameter = mi.getReqInfo().getParams();
		//parameter: aucCnt
		ParameterInfo aucCnt = new ParameterInfo();
		aucCnt.setName("aucCnt");
		aucCnt.setType("String");
		aucCnt.setValueeg("B010528");
		aucCnt.setNotNull("yes");
		aucCnt.setDescription("開催回数");
		listParameter.add(aucCnt);
		//parameter:entryNo
		ParameterInfo entryNo = new ParameterInfo();
		entryNo.setName("entryNo");
		entryNo.setType("String");
		entryNo.setValueeg("S00001");
		entryNo.setNotNull("yes");
		entryNo.setDescription("出品番号");
		listParameter.add(entryNo);
		
		//response result sample
		mi.getResInfo().setResultOK("{ result=true}");
		mi.getResInfo().setResultNG("{ result=false}");
		
		//curd 
		List<CRUDInfo> listCRUDInfo = mi.getCurdInfo();
		CRUDInfo table1 = new CRUDInfo();
		table1.setNo("01");
		table1.setOperation("SELECT");
		table1.setTablename("table1");
		table1.setDiscription("Description");
		listCRUDInfo.add(table1);
		
		return mi;
	}
	
}
