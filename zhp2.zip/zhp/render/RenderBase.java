package zhp.render;


import java.util.List;

import zhp.template.MethodInfo;
import zhp.template.WikiDocument;
import zhp.util.Util;

abstract public class RenderBase {

	protected WikiDocument sdoc;
	
	abstract void setWikiDocInfo();
	
	public void render(WikiDocument ddoc){
		
		//sub class set the info
		this.setWikiDocInfo();
		
		//summary
		ddoc.setWikiSummaryContent(sdoc.getWikiSummaryContent());
		
		//forms
		ddoc.setWikiFormsContent(sdoc.getWikiFormsContent());
		
		//methods
		List<MethodInfo> listMethodInfo = ddoc.getListMethod();
		for( MethodInfo m:listMethodInfo ){
			MethodInfo renderedMethod = this.findMethodInfo(m.getFunctionName(), sdoc.getListMethod());
			if( renderedMethod!=null ){
				this.renderMethod(m, renderedMethod);
			}
		}
	}
	
	private void renderMethod(MethodInfo target, MethodInfo render){
		//status
		if( Util.isNotEmpty(render.getStatus())){
			target.setStatus(render.getStatus());
		}
		
		//description
		if( Util.isNotEmpty(render.getDescription())){
			target.setDescription(render.getDescription());
		}
		
		//sampleUrl
		if( Util.isNotEmpty(render.getReqInfo().getSampleUrl())){
			target.getReqInfo().setSampleUrl(render.getReqInfo().getSampleUrl());
		}
		
		//parameters
		if( render.getReqInfo().getParams().size() > 0 ){
			target.getReqInfo().setParams(render.getReqInfo().getParams());
		}
		
		//OK sample
		if( Util.isNotEmpty(render.getResInfo().getResultOK()) ){
			target.getResInfo().setResultOK(render.getResInfo().getResultOK());
		}
		
		//NG sample
		if( Util.isNotEmpty(render.getResInfo().getResultNG()) ){
			target.getResInfo().setResultNG(render.getResInfo().getResultNG());
		}
		
		//CRUD
		if( render.getCurdInfo().size() > 0){
			target.setCurdInfo(render.getCurdInfo());
		}
		
	}
	
	private MethodInfo findMethodInfo(String functionName, List<MethodInfo> listMethod){
		MethodInfo result = null;
		for( MethodInfo m : listMethod ){
			if( m.getFunctionName() != null && m.getFunctionName().length() > 0 ){
				if(functionName.equals(m.getFunctionName())){
					result = m;
					break;
				}
			}
		}
		return result;
	}

	
}
