package zhp.util;

public class Util {

	static final String cf = "\n";
	static final String sp = " | ";
	static final String space = " ";
	
	
	public static String wrapString(String input){
		return "`" + input + "`";
	}
	
	public static String wrapJson(String input){
		return "```json" + cf + input + cf + " ```"; 
	}
	
	public static boolean isEmpty(String input){
		if(input == null || input.length() == 0){
			return true;
		}
		else{
			return false;
		} 
	}
	public static boolean isNotEmpty(String input){
		return !isEmpty(input);
	}
	
	public static String wrapNumber(String input){
		input = input.replaceAll("0", ":zero:");
		input = input.replaceAll("1", ":one:");
		input = input.replaceAll("2", ":two:");
		input = input.replaceAll("3", ":three:");
		input = input.replaceAll("4", ":four:");
		input = input.replaceAll("5", ":five:");
		input = input.replaceAll("6", ":six:");
		input = input.replaceAll("7", ":seven:");
		input = input.replaceAll("8", ":eight:");
		input = input.replaceAll("9", ":nine:");
		return input;
	}
	
	public static String printApiListHeader(){
		StringBuffer sb = new StringBuffer();
		sb.append("#### API一覧").append(cf);
    	sb.append("No   | http method | resource                                                    | State").append(cf);
    	sb.append(":--- | :---------- | :---------------------------------------------------------- | :----").append(cf);
		return sb.toString();
	}
	public static String printDescriptionHeader(){
		StringBuffer sb = new StringBuffer();
		sb.append("- Description");
    	sb.append(cf).append(cf);
		return sb.toString();
	}
	public static String printRequestHeader(){
		StringBuffer sb = new StringBuffer();
		sb.append("- Request");
    	sb.append(cf).append(cf);
    	sb.append("Parameter Name | type     | value(eg)  | Not Null | Description");
    	sb.append(cf);
    	sb.append(":------------- | :------- | :--------- | :------- | :-------------------");
    	sb.append(cf);
		return sb.toString();
	}
	public static String printResponseHeader(){
		StringBuffer sb = new StringBuffer();
		sb.append("- Response");
    	sb.append(cf).append(cf);
		return sb.toString();
	}
	public static String printCRUDHeader(){
		StringBuffer sb = new StringBuffer();
		sb.append("- CRUD").append(cf).append(cf);
		sb.append("No   | operation | table name                | discription").append(cf);
    	sb.append(":--- | :---------- | :---------------------- | :----------------------------------------").append(cf);
		return sb.toString();
	}
	
}
