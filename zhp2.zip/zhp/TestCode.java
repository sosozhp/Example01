package zhp;

import jp.co.aucnet.nmc.api.v1.BidRestControllerV1;
import zhp.render.BidRestControllerV1Render;
import zhp.template.MethodInfoMgr;

public class TestCode {

    public static void main(String[] args) {

    	MethodInfoMgr.getInstance().setRender(null);
        MethodInfoMgr.getInstance().setup(BidRestControllerV1.class);
        MethodInfoMgr.output();
    }

}
